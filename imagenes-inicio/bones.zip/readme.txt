Thank you for your interest in DinPattern. I hope you find these patterns useful.
If you've used this pattern for your own website, a little credit might be nice. 

Thanks again, and enjoy!

Evan

evaneckard.com



